extern int getchar();
int hello() {return getchar();}
