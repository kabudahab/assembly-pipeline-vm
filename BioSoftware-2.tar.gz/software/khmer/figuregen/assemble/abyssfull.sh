mpirun -np 8 ABYSS-P -k33 -o contigs.fa msb2.fq
