#!/bin/sh

rm -f contigs.*
rm -f msb2.dist
rm -f msb2.fa
rm -f msb2.fa.part
rm -f msb2.group*
rm -f msb2.ht
rm -f msb2.info
rm -f msb2.pmap.merged
rm -f msb2.tagset
