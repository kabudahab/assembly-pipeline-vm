python ctb-iterative-bench-2.py
python filter-exact.py foo.fa xxx
python filter-inexact-all.py foo.fa yyy
python filter-inexact-any.py foo.fa zzz
python filter-inexact-run.py foo.fa aaa
python occupy.py foo.fa 12
