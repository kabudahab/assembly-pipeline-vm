See ../doc/scripts.txt for basic documentation.
